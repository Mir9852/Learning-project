import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class HistoryServiceUserScreen extends StatefulWidget {
  const HistoryServiceUserScreen({super.key});

  @override
  State<HistoryServiceUserScreen> createState() =>
      _HistoryServiceUserScreenState();
}

class _HistoryServiceUserScreenState extends State<HistoryServiceUserScreen> {
  final SupabaseClient supabase = Supabase.instance.client;

  bool isLoading = true;
  List<dynamic> _riwayatServisData = [];

  @override
  void initState() {
    super.initState();

    _getRiwayatServis();
  }

  Future<void> _getRiwayatServis() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();

      final resRiwayatServis = await supabase
          .from('wo_service')
          .select()
          .eq('id_pelanggan', prefs.getString('userId')!)
          .order('created_at', ascending: true);

      if (resRiwayatServis.isNotEmpty) {
        if (mounted) {
          setState(() {
            _riwayatServisData = resRiwayatServis;
          });
        }
      }
    } catch (e) {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Internal Server Error',
              style: TextStyle(fontSize: 14.0, color: Colors.white)),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: RefreshIndicator(
            onRefresh: _getRiwayatServis,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Text(
                    'Riwayat Servis',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Expanded(
                  child: isLoading
                      ? const Center(
                          child: CircularProgressIndicator(),
                        )
                      : _riwayatServisData.isEmpty
                          ? const Center(
                              child: Text(
                                'Tidak ada riwayat servis',
                                style: TextStyle(color: Colors.black),
                              ),
                            )
                          : ListView.builder(
                              itemCount: _riwayatServisData.length,
                              itemBuilder: (context, index) {
                                final data = _riwayatServisData[index];

                                DateTime date =
                                    DateTime.parse(data['tanggal_service']);
                                String formattedDate =
                                    DateFormat('dd MMMM yyyy', 'id_ID')
                                        .format(date);

                                final parseTotal =
                                    double.parse(data['total_biaya']);

                                final totalBiaya = NumberFormat.currency(
                                  decimalDigits: 0,
                                  symbol: 'Rp ',
                                  name: 'IDR',
                                ).format(parseTotal);

                                return Container(
                                  decoration: BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: Colors.grey.shade300,
                                        width: 1.0,
                                      ),
                                    ),
                                  ),
                                  child: ListTile(
                                    title: Text(formattedDate,
                                        style: const TextStyle(
                                          color: Colors.black,
                                          fontSize: 16.0,
                                          fontWeight: FontWeight.bold,
                                        )),
                                    subtitle: Padding(
                                      padding: const EdgeInsets.only(top: 8.0),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                              'Tipe Mobil : ${data['tipe_kendaraan']}'),
                                          Text(
                                              'Jenis Service : ${data['jenis_service']}'),
                                          Text('Biaya : $totalBiaya'),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                )
              ],
            ),
          ),
        ));
  }
}
