import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class HistoryDiagnoseVehiclesScreen extends StatefulWidget {
  const HistoryDiagnoseVehiclesScreen({super.key});

  @override
  State<HistoryDiagnoseVehiclesScreen> createState() =>
      _HistoryDiagnoseVehiclesScreenState();
}

class _HistoryDiagnoseVehiclesScreenState
    extends State<HistoryDiagnoseVehiclesScreen> {
  final SupabaseClient supabase = Supabase.instance.client;

  bool isLoading = true;
  List<dynamic> _diagnoseVehiclesData = [];

  @override
  void initState() {
    super.initState();

    _getRiwayatDiagnosa();
  }

  Future<void> _getRiwayatDiagnosa() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();

      final resRiwayatDiagnosa = await supabase
          .from('diagnosa_kendaraan')
          .select()
          .eq('id_pelanggan', prefs.getString('userId')!)
          .order('created_at', ascending: true);

      if (resRiwayatDiagnosa.isNotEmpty) {
        if (mounted) {
          setState(() {
            _diagnoseVehiclesData = resRiwayatDiagnosa;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _diagnoseVehiclesData = [];
          });
        }
      }
    } catch (e) {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Internal Server Error',
              style: TextStyle(fontSize: 14.0, color: Colors.white)),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
          child: RefreshIndicator(
        onRefresh: _getRiwayatDiagnosa,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: isLoading
              ? const Center(
                  child: CircularProgressIndicator(),
                )
              : _diagnoseVehiclesData.isEmpty
                  ? const Center(
                      child: Text(
                        'Tidak ada riwayat diagnosa',
                        style: TextStyle(color: Colors.black),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _diagnoseVehiclesData.length,
                      itemBuilder: (context, index) {
                        final data = _diagnoseVehiclesData[index];

                        DateTime date = DateTime.parse(data['created_at']);
                        String formattedDate =
                            DateFormat('dd MMMM yyyy HH:mm', 'id_ID')
                                .format(date);

                        return ExpansionTile(
                          title: Text(
                            formattedDate,
                            style: const TextStyle(
                              color: Colors.black,
                              fontSize: 14.0,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          expandedCrossAxisAlignment: CrossAxisAlignment.start,
                          tilePadding:
                              const EdgeInsets.only(left: 10.0, right: 10.0),
                          childrenPadding: const EdgeInsets.all(10.0),
                          expandedAlignment: Alignment.centerLeft,
                          collapsedShape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                            side: BorderSide.none,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                            side: BorderSide.none,
                          ),
                          children: [
                            const Text(
                              'Keluhan: ',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              data['detail_kerusakan'],
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 14.0,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 10.0),
                              child: Divider(
                                  color: Colors.black.withOpacity(0.5),
                                  thickness: 1.0),
                            ),
                            const Text(
                              'Hasil Diagnosa: ',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              data['hasil_analisa'] ?? '-',
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 14.0,
                              ),
                            ),
                          ],
                        );
                      }),
        ),
      )),
    );
  }
}
