import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class FormDiagnoseVehiclesScreen extends StatefulWidget {
  const FormDiagnoseVehiclesScreen({super.key});

  @override
  State<FormDiagnoseVehiclesScreen> createState() =>
      _FormDiagnoseVehiclesScreenState();
}

class _FormDiagnoseVehiclesScreenState
    extends State<FormDiagnoseVehiclesScreen> {
  final SupabaseClient supabase = Supabase.instance.client;

  final _formKey = GlobalKey<FormState>();
  final _detailDamageController = TextEditingController();

  List _complaintCategory = [];
  List _diagnoseVehiclesData = [];
  String? _complaintCategoryValue;

  @override
  void initState() {
    super.initState();

    readJson();
  }

  Future<void> readJson() async {
    final String response = await rootBundle.loadString('assets/diagnosa.json');
    final data = await json.decode(response);

    final List<dynamic> kategoriList = data.map((item) {
      return item['kategori'] as String;
    }).toList();

    setState(() {
      _complaintCategory = kategoriList;
      _diagnoseVehiclesData = data;
    });
  }

  Future<void> _handleDiagnose() async {
    try {
      if (_formKey.currentState!.validate()) {
        final SharedPreferences prefs = await SharedPreferences.getInstance();

        EasyLoading.show(status: 'Loading...');

        await supabase.from('diagnosa_kendaraan').insert({
          'id_pelanggan': prefs.getString('userId'),
          'detail_kerusakan': _detailDamageController.text,
          'created_at': DateTime.now().toIso8601String(),
        });

        EasyLoading.showSuccess('Diagnosa kendaraan berhasil dikirim');
      }
    } catch (e) {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Internal Server Error',
              style: TextStyle(fontSize: 14.0, color: Colors.white)),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      EasyLoading.dismiss();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Diagnosa Kerusakan Kendaraan',
                  style: TextStyle(
                    fontSize: 24.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 20.0),
                DropdownButtonFormField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide(
                        color: Colors.grey.withOpacity(0.5),
                        width: 1.0,
                      ),
                    ),
                  ),
                  items: _complaintCategory
                      .map((e) => DropdownMenuItem(
                            value: e,
                            child: Text(e),
                          ))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      _complaintCategoryValue = value.toString();
                    });
                  },
                ),
                const SizedBox(height: 10.0),
                Visibility(
                  visible: _complaintCategoryValue != null,
                  child: ListView(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    children: _diagnoseVehiclesData
                        .where((element) =>
                            element['kategori'] == _complaintCategoryValue)
                        .map((data) {
                      return Column(
                        children: [
                          ...data['penyebab'].map<Widget>((cause) {
                            final index = data['penyebab'].indexOf(cause);
                            final solution = data['solusi'][index];

                            return ExpansionTile(
                              title: Text(
                                cause,
                                style: const TextStyle(
                                  color: Colors.black,
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              expandedCrossAxisAlignment:
                                  CrossAxisAlignment.start,
                              tilePadding: const EdgeInsets.only(
                                  left: 10.0, right: 10.0),
                              childrenPadding: const EdgeInsets.all(10.0),
                              expandedAlignment: Alignment.centerLeft,
                              collapsedShape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                side: BorderSide.none,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                side: BorderSide.none,
                              ),
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text('Solusi: $solution'),
                                ),
                              ],
                            );
                          }).toList(),
                        ],
                      );
                    }).toList(),
                  ),
                ),
                Visibility(
                  visible: _complaintCategoryValue != null,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 40.0),
                      const Text(
                        'Masalah belum teratasi ? Silakan isi form dibawah ini untuk diagnosa lebih lanjut oleh teknisi kami',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14.0,
                        ),
                      ),
                      const SizedBox(height: 20.0),
                      Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Detail Kerusakan',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 14.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8.0),
                            TextFormField(
                              controller: _detailDamageController,
                              decoration: InputDecoration(
                                filled: true,
                                fillColor: Colors.white,
                                contentPadding: const EdgeInsets.all(12.0),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                  borderSide: BorderSide(
                                    color: Colors.grey.withOpacity(0.5),
                                    width: 1.0,
                                  ),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                  borderSide: const BorderSide(
                                    color: Color(0xffe42025),
                                    width: 2.0,
                                  ),
                                ),
                                errorBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                  borderSide: const BorderSide(
                                    color: Colors.red,
                                    width: 1.0,
                                  ),
                                ),
                                focusedErrorBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                  borderSide: const BorderSide(
                                    color: Colors.red,
                                    width: 1.0,
                                  ),
                                ),
                                hintText: 'Masukan Detail Kerusakan',
                                hintStyle: TextStyle(
                                  color: Colors.black.withOpacity(0.5),
                                  fontSize: 14.0,
                                ),
                              ),
                              maxLines: 6,
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Masukan Detail Kerusakan';
                                }
                                return null;
                              },
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 14.0,
                              ),
                            ),
                            const SizedBox(height: 16.0),
                            SizedBox(
                              width: double.infinity,
                              height: 48.0,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xffe42025),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                ),
                                onPressed: _handleDiagnose,
                                child: const Text(
                                  'Kirim Diagnosa',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
