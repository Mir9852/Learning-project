import 'package:flutter/material.dart';
import 'package:hondasmartcare/screens/cco/booking_service_cco_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class GreetingsHelper {
  static String getGreetings() {
    var hour = DateTime.now().hour;

    if (hour < 12) {
      return 'Selamat Pagi';
    }
    if (hour < 18) {
      return 'Selamat Siang';
    }
    return 'Selamat Malam';
  }
}

class DashboardCcoScreen extends StatefulWidget {
  const DashboardCcoScreen({super.key});

  @override
  State<DashboardCcoScreen> createState() => _DashboardCcoScreenState();
}

class _DashboardCcoScreenState extends State<DashboardCcoScreen> {
  final SupabaseClient supabase = Supabase.instance.client;

  String greetings = GreetingsHelper.getGreetings();
  String user = '';
  String totalBookingService = '';

  @override
  void initState() {
    super.initState();

    _getDashboard();
  }

  Future<void> _getDashboard() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();

      final resTotalBookingService = await supabase
          .from('booking_service')
          .select()
          .isFilter('status', null)
          .count();

      if (mounted) {
        setState(() {
          user = prefs.getString('nama')!;
          totalBookingService = resTotalBookingService.count.toString();
        });
      }
    } catch (e) {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Internal Server Error',
              style: TextStyle(fontSize: 14.0, color: Colors.white)),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$greetings,',
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 16.0,
                  ),
                ),
                Text(
                  user,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10.0),
                SizedBox(
                  width: double.infinity,
                  child: Card(
                    color: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Permintaan Booking Service',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 20.0,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 10.0),
                          Text(
                            totalBookingService,
                            style: const TextStyle(
                              color: Colors.black,
                              fontSize: 24.0,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 10.0),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        label: const Text(
          'Booking Service',
          style: TextStyle(
              color: Colors.white, fontSize: 14.0, fontWeight: FontWeight.bold),
        ),
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (context) {
            return const BookingServiceCcoScreen();
          }));

          _getDashboard();
        },
        backgroundColor: const Color(0xffe42025),
      ),
    );
  }
}
