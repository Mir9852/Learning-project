import 'package:flutter/material.dart';
import 'package:hondasmartcare/screens/user/widgets/form_diagnose_vehicles_screen.dart';
import 'package:hondasmartcare/screens/user/widgets/history_diagnose_vehicles_screen.dart';

class DiagnoseVehiclesUserScreen extends StatefulWidget {
  const DiagnoseVehiclesUserScreen({super.key});

  @override
  State<DiagnoseVehiclesUserScreen> createState() =>
      _DiagnoseVehiclesUserScreenState();
}

class _DiagnoseVehiclesUserScreenState
    extends State<DiagnoseVehiclesUserScreen> {
  int _index = 0;

  final List<Widget> _screens = [
    const FormDiagnoseVehiclesScreen(),
    const HistoryDiagnoseVehiclesScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Diagnosa Kerusakan'),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: _screens[_index],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        currentIndex: _index,
        onTap: (int index) {
          setState(() {
            _index = index;
          });
        },
        selectedLabelStyle: const TextStyle(
          fontWeight: FontWeight.bold,
        ),
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.list_alt),
            label: 'Diagnosa',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'Riwayat Diagnosa',
          ),
        ],
      ),
    );
  }
}
