import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class NotificationUserScreen extends StatefulWidget {
  const NotificationUserScreen({super.key});

  @override
  State<NotificationUserScreen> createState() => _NotificationUserScreenState();
}

class _NotificationUserScreenState extends State<NotificationUserScreen> {
  final SupabaseClient supabase = Supabase.instance.client;

  bool isLoading = true;
  List<dynamic> _notificationData = [];

  @override
  void initState() {
    super.initState();

    _getNotifikasi();
  }

  Future<void> _getNotifikasi() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();

      final resNotifikasi = await supabase
          .from('notifikasi')
          .select()
          .eq('id_pelanggan', prefs.getString('userId')!)
          .order('created_at', ascending: true);

      if (resNotifikasi.isNotEmpty) {
        if (mounted) {
          setState(() {
            _notificationData = resNotifikasi;
          });
        }
      }
    } catch (e) {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Internal Server Error',
              style: TextStyle(fontSize: 14.0, color: Colors.white)),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: RefreshIndicator(
            onRefresh: _getNotifikasi,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Text(
                    'Notifikasi',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Expanded(
                  child: isLoading
                      ? const Center(
                          child: CircularProgressIndicator(),
                        )
                      : _notificationData.isEmpty
                          ? const Center(
                              child: Text(
                                'Tidak ada notifikasi',
                                style: TextStyle(color: Colors.black),
                              ),
                            )
                          : ListView.builder(
                              itemCount: _notificationData.length,
                              itemBuilder: (context, index) {
                                final notif = _notificationData[index];

                                DateTime date =
                                    DateTime.parse(notif['created_at']);
                                String formattedDate =
                                    DateFormat('dd MMMM yyyy', 'id_ID')
                                        .format(date);

                                return Container(
                                  decoration: BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: Colors.black.withOpacity(0.5),
                                        width: 1.0,
                                      ),
                                    ),
                                  ),
                                  child: ListTile(
                                    title: Text(
                                      notif['judul'] ?? '',
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    subtitle: Padding(
                                      padding: const EdgeInsets.only(top: 8.0),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            notif['pesan'],
                                            style: const TextStyle(
                                              color: Colors.black,
                                              fontSize: 14.0,
                                            ),
                                          ),
                                          Text(
                                            notif['created_at'] != null
                                                ? formattedDate
                                                : '',
                                            style: const TextStyle(
                                              color: Colors.black,
                                              fontSize: 12.0,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                )
              ],
            ),
          ),
        ));
  }
}
