import 'package:flutter/material.dart';
import 'package:hondasmartcare/screens/cco/details_booking_service_cco_screen.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class BookingServiceCcoScreen extends StatefulWidget {
  const BookingServiceCcoScreen({super.key});

  @override
  State<BookingServiceCcoScreen> createState() =>
      _BookingServiceCcoScreenState();
}

class _BookingServiceCcoScreenState extends State<BookingServiceCcoScreen> {
  final SupabaseClient supabase = Supabase.instance.client;

  bool isLoading = true;
  List<dynamic> bookingServiceList = [];

  @override
  void initState() {
    super.initState();

    _getBookingService();
  }

  Future<void> _getBookingService() async {
    try {
      final resBookingService = await supabase
          .from('booking_service')
          .select()
          .isFilter('status', null)
          .order('created_at', ascending: true);

      if (mounted) {
        setState(() {
          bookingServiceList = resBookingService;
        });
      }
    } catch (e) {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Internal Server Error',
              style: TextStyle(fontSize: 14.0, color: Colors.white)),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Booking Service'),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _getBookingService,
          child: isLoading
              ? const Center(
                  child: CircularProgressIndicator(),
                )
              : bookingServiceList.isEmpty
                  ? const Center(
                      child: Text(
                        'Tidak ada booking service',
                        style: TextStyle(color: Colors.black),
                      ),
                    )
                  : ListView.builder(
                      itemCount: bookingServiceList.length,
                      itemBuilder: (context, index) {
                        final data = bookingServiceList[index];

                        DateTime date = DateTime.parse(data['tanggal_service']);
                        String formattedDate =
                            DateFormat('dd MMMM yyyy', 'id_ID').format(date);

                        return Container(
                          decoration: BoxDecoration(
                            border: Border(
                              bottom: BorderSide(
                                color: Colors.black.withOpacity(0.5),
                                width: 1.0,
                              ),
                            ),
                          ),
                          child: ListTile(
                            onTap: () async {
                              await Navigator.push(context,
                                  MaterialPageRoute(builder: (context) {
                                return DetailsBookingServiceCcoScreen(
                                  idBookingService:
                                      data['id_booking_service'].toString(),
                                );
                              }));

                              _getBookingService();
                            },
                            title: Text(data['nama_pelanggan']),
                            subtitle: Text(formattedDate),
                            trailing: const Icon(Icons.arrow_forward_ios),
                          ),
                        );
                      }),
        ),
      ),
    );
  }
}
