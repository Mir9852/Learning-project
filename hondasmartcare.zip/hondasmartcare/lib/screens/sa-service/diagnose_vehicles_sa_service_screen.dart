import 'package:flutter/material.dart';
import 'package:hondasmartcare/screens/sa-service/form_diagnose_vehicles_sa_service_screen.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class DiagnoseVehiclesSaServiceScreen extends StatefulWidget {
  const DiagnoseVehiclesSaServiceScreen({super.key});

  @override
  State<DiagnoseVehiclesSaServiceScreen> createState() =>
      _DiagnoseVehiclesSaServiceScreenState();
}

class _DiagnoseVehiclesSaServiceScreenState
    extends State<DiagnoseVehiclesSaServiceScreen> {
  final SupabaseClient supabase = Supabase.instance.client;

  bool isLoading = true;
  List<dynamic> _diagnoseVehiclesData = [];

  @override
  void initState() {
    super.initState();

    _getDiagnose();
  }

  Future<void> _getDiagnose() async {
    try {
      final getDiagnosa = await supabase
          .from('diagnosa_kendaraan')
          .select('*, pelanggan(nama_pelanggan)')
          .isFilter('hasil_analisa', null)
          .order('created_at', ascending: true);

      if (getDiagnosa.isNotEmpty) {
        if (mounted) {
          setState(() {
            _diagnoseVehiclesData = getDiagnosa;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _diagnoseVehiclesData = [];
          });
        }
      }
    } catch (e) {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Internal Server Error',
              style: TextStyle(fontSize: 14.0, color: Colors.white)),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Diagnosa Kendaraan'),
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
          child: RefreshIndicator(
        onRefresh: _getDiagnose,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: isLoading
              ? const Center(
                  child: CircularProgressIndicator(),
                )
              : _diagnoseVehiclesData.isEmpty
                  ? const Center(
                      child: Text(
                        'Tidak ada permintaan diagnosa kendaraan',
                        style: TextStyle(color: Colors.black),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _diagnoseVehiclesData.length,
                      itemBuilder: (context, index) {
                        final data = _diagnoseVehiclesData[index];

                        DateTime date = DateTime.parse(data['created_at']);
                        String formattedDate =
                            DateFormat('dd MMMM yyyy HH:mm', 'id_ID')
                                .format(date);

                        return Container(
                          decoration: BoxDecoration(
                            border: Border(
                              bottom: BorderSide(
                                color: Colors.grey.shade300,
                                width: 1.0,
                              ),
                            ),
                          ),
                          child: ListTile(
                            title: Text(
                              data['pelanggan']['nama_pelanggan'],
                              style: const TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Text(formattedDate),
                            onTap: () async {
                              await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      FormDiagnoseVehiclesSaServiceScreen(
                                    idDiagnoseVehicles: data['id'].toString(),
                                    idPelanggan:
                                        data['id_pelanggan'].toString(),
                                  ),
                                ),
                              );

                              _getDiagnose();
                            },
                          ),
                        );
                      }),
        ),
      )),
    );
  }
}
