import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ListBookingServiceScreen extends StatefulWidget {
  const ListBookingServiceScreen({super.key});

  @override
  State<ListBookingServiceScreen> createState() =>
      _ListBookingServiceScreenState();
}

class _ListBookingServiceScreenState extends State<ListBookingServiceScreen> {
  final SupabaseClient supabase = Supabase.instance.client;

  bool isLoading = true;
  List<dynamic> _bookingServiceData = [];

  @override
  void initState() {
    super.initState();

    _getRiwayatDiagnosa();
  }

  Future<void> _getRiwayatDiagnosa() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();

      final resBookingService = await supabase
          .from('booking_service')
          .select()
          .eq('id_pelanggan', prefs.getString('userId')!)
          .order('created_at', ascending: true);

      if (resBookingService.isNotEmpty) {
        if (mounted) {
          setState(() {
            _bookingServiceData = resBookingService;
          });
        }
      }
    } catch (e) {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Internal Server Error',
              style: TextStyle(fontSize: 14.0, color: Colors.white)),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _getRiwayatDiagnosa,
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: isLoading
                ? const Center(
                    child: CircularProgressIndicator(),
                  )
                : _bookingServiceData.isEmpty
                    ? const Center(
                        child: Text(
                          'Tidak ada daftar permintaan servis',
                          style: TextStyle(color: Colors.black),
                        ),
                      )
                    : ListView.builder(
                        itemCount: _bookingServiceData.length,
                        itemBuilder: (context, index) {
                          final data = _bookingServiceData[index];

                          DateTime date =
                              DateTime.parse(data['tanggal_service']);
                          String formattedDate =
                              DateFormat('dd MMMM yyyy', 'id_ID').format(date);

                          return ExpansionTile(
                            title: Text(formattedDate),
                            subtitle: Text(
                                'Status : ${data['status'] ?? 'Menunggu'}'),
                            expandedCrossAxisAlignment:
                                CrossAxisAlignment.start,
                            tilePadding:
                                const EdgeInsets.only(left: 10.0, right: 10.0),
                            childrenPadding: const EdgeInsets.all(10.0),
                            expandedAlignment: Alignment.centerLeft,
                            collapsedShape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              side: BorderSide.none,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              side: BorderSide.none,
                            ),
                            children: [
                              const Text(
                                'Permintaan Servis: ',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                data['jenis_service'],
                                style: const TextStyle(
                                  color: Colors.black,
                                  fontSize: 14.0,
                                ),
                              ),
                            ],
                          );
                        }),
          ),
        ),
      ),
    );
  }
}
