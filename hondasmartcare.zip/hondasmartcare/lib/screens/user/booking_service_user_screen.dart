import 'package:flutter/material.dart';
import 'package:hondasmartcare/screens/user/widgets/form_booking_service_screen.dart';
import 'package:hondasmartcare/screens/user/widgets/list_booking_service_screen.dart';

class BookingServiceUserScreen extends StatefulWidget {
  const BookingServiceUserScreen({super.key});

  @override
  State<BookingServiceUserScreen> createState() =>
      _BookingServiceUserScreenState();
}

class _BookingServiceUserScreenState extends State<BookingServiceUserScreen> {
  int _index = 0;

  final List<Widget> _screens = [
    const FormBookingServiceScreen(),
    const ListBookingServiceScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Booking Service'),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: _screens[_index],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        currentIndex: _index,
        onTap: (int index) {
          setState(() {
            _index = index;
          });
        },
        selectedLabelStyle: const TextStyle(
          fontWeight: FontWeight.bold,
        ),
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.list_alt),
            label: 'Form Booking',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'Daftar Permintaan',
          ),
        ],
      ),
    );
  }
}
