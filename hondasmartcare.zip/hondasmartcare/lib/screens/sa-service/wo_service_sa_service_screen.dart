import 'package:flutter/material.dart';
import 'package:hondasmartcare/screens/sa-service/details_wo_service_sa_service_screen.dart';
import 'package:hondasmartcare/screens/sa-service/form_wo_service_sa_service_screen.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class WoServiceSaServiceScreen extends StatefulWidget {
  const WoServiceSaServiceScreen({super.key});

  @override
  State<WoServiceSaServiceScreen> createState() =>
      _WoServiceSaServiceScreenState();
}

class _WoServiceSaServiceScreenState extends State<WoServiceSaServiceScreen> {
  final SupabaseClient supabase = Supabase.instance.client;

  bool isLoading = true;
  List<dynamic> woServiceList = [];

  @override
  void initState() {
    super.initState();

    _getWoService();
  }

  Future<void> _getWoService() async {
    try {
      final resWoService = await supabase
          .from('wo_service')
          .select()
          .eq('status', '')
          .order('created_at', ascending: true);

      if (mounted) {
        setState(() {
          woServiceList = resWoService;
        });
      }
    } catch (e) {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Internal Server Error',
              style: TextStyle(fontSize: 14.0, color: Colors.white)),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('WO Service'),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _getWoService,
          child: isLoading
              ? const Center(
                  child: CircularProgressIndicator(),
                )
              : woServiceList.isEmpty
                  ? const Center(
                      child: Text(
                        'Tidak ada data wo service',
                        style: TextStyle(color: Colors.black),
                      ),
                    )
                  : ListView.builder(
                      itemCount: woServiceList.length,
                      itemBuilder: (context, index) {
                        final data = woServiceList[index];

                        DateTime date = DateTime.parse(data['tanggal_service']);
                        String formattedDate =
                            DateFormat('dd MMMM yyyy', 'id_ID').format(date);

                        return Container(
                          decoration: BoxDecoration(
                            border: Border(
                              bottom: BorderSide(
                                color: Colors.black.withOpacity(0.5),
                                width: 1.0,
                              ),
                            ),
                          ),
                          child: ListTile(
                            onTap: () async {
                              await Navigator.push(context,
                                  MaterialPageRoute(builder: (context) {
                                return DetailsWoServiceSaServiceScreen(
                                  idWoService: data['id'].toString(),
                                );
                              }));

                              _getWoService();
                            },
                            title: Text(
                              data['nama_pelanggan'],
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 16.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Text(
                              formattedDate,
                              style: TextStyle(
                                color: Colors.black.withOpacity(0.5),
                              ),
                            ),
                            trailing: const Icon(Icons.arrow_forward_ios),
                          ),
                        );
                      }),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        label: const Text(
          'Tambah WO Service',
          style: TextStyle(
              color: Colors.white, fontSize: 14.0, fontWeight: FontWeight.bold),
        ),
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (context) {
            return const FormWoServiceSaServiceScreen();
          }));

          _getWoService();
        },
        backgroundColor: const Color(0xffe42025),
      ),
    );
  }
}
