import 'package:flutter/material.dart';
import 'package:hondasmartcare/screens/cco/dashboard_cco_screen.dart';
import 'package:hondasmartcare/screens/cco/profile_cco_screen.dart';
import 'package:hondasmartcare/screens/sa-service/dashboard_sa_service_screen.dart';
import 'package:hondasmartcare/screens/sa-service/history_service_sa_service_screen.dart';
import 'package:hondasmartcare/screens/sa-service/profile_sa_service_screen.dart';
import 'package:hondasmartcare/screens/user/dashboard_user_screen.dart';
import 'package:hondasmartcare/screens/user/history_service_user_screen.dart';
import 'package:hondasmartcare/screens/user/notification_user_screen.dart';
import 'package:hondasmartcare/screens/user/profile_user_screen.dart';

class HomeScreen extends StatefulWidget {
  final String role;
  const HomeScreen({required this.role, super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  final List<Widget> _userScreen = [
    const DashboardUserScreen(),
    const HistoryServiceUserScreen(),
    const NotificationUserScreen(),
    const ProfileUserScreen(),
  ];

  final List<Widget> _ccoScreen = [
    const DashboardCcoScreen(),
    const ProfileCcoScreen()
  ];

  final List<Widget> _saServiceScreen = [
    const DashboardSaServiceScreen(),
    const HistoryServiceSaServiceScreen(),
    const ProfileSaServiceScreen()
  ];

  final List<BottomNavigationBarItem> _userBottomNav = [
    const BottomNavigationBarItem(
      icon: Icon(Icons.home),
      label: 'Dashboard',
    ),
    const BottomNavigationBarItem(
      icon: Icon(Icons.history),
      label: 'Riwayat Servis',
    ),
    const BottomNavigationBarItem(
      icon: Icon(Icons.notifications),
      label: 'Notifikasi',
    ),
    const BottomNavigationBarItem(
      icon: Icon(Icons.person),
      label: 'Profil',
    ),
  ];

  final List<BottomNavigationBarItem> _ccoBottomNav = [
    const BottomNavigationBarItem(
      icon: Icon(Icons.home),
      label: 'Dashboard',
    ),
    const BottomNavigationBarItem(
      icon: Icon(Icons.person),
      label: 'Profil',
    ),
  ];

  final List<BottomNavigationBarItem> _saBottomNav = [
    const BottomNavigationBarItem(
      icon: Icon(Icons.home),
      label: 'Dashboard',
    ),
    const BottomNavigationBarItem(
      icon: Icon(Icons.history),
      label: 'Riwayat Servis',
    ),
    const BottomNavigationBarItem(
      icon: Icon(Icons.person),
      label: 'Profil',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset('assets/images/honda_fatmawati.png', width: 120.0),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: widget.role == 'user'
          ? _userScreen[_index]
          : widget.role == 'cco'
              ? _ccoScreen[_index]
              : _saServiceScreen[_index],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        currentIndex: _index,
        type: BottomNavigationBarType.fixed,
        onTap: (int index) {
          setState(() {
            _index = index;
          });
        },
        selectedLabelStyle: const TextStyle(
          fontWeight: FontWeight.bold,
        ),
        items: widget.role == 'user'
            ? _userBottomNav
            : widget.role == 'cco'
                ? _ccoBottomNav
                : _saBottomNav,
      ),
    );
  }
}
